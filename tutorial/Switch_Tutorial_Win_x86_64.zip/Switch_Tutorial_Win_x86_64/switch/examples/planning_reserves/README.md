SYNOPSIS
	switch solve --verbose --log-run

This example adapts the 3zone toy model to include planning reserves. Other
changes include lowering the cost of solar to put it on the margin and
illustrate more dynamics, and registering distributed solar as a DER for
better accounting of distribution losses. 
