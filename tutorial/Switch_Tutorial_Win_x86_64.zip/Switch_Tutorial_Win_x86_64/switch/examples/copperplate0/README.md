SYNOPSIS
	switch solve --verbose --log-run

This example illustrates the use of Switch to construct and run a very
simple model with a single load zone, one investment period, and two
timepoints.  This model neglects local transmission and distribution
as well.
