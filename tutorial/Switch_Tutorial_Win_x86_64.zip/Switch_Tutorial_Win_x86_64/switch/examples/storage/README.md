SYNOPSIS
	switch solve --verbose --log-run

This example illustrates the use of storage. It is very similar to the
copperplate0 example.
