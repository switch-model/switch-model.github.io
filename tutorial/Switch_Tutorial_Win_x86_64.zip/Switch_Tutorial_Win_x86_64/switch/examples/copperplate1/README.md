SYNOPSIS
	switch solve --verbose --log-run

This example illustrates the use of Switch to construct and run a very
simple model with a single load zone, one investment period, and two
timepoints.  This expands on copperplate0 by adding a few more types
of generators, fuel supply curves, as well as local transmission and
distribution.
