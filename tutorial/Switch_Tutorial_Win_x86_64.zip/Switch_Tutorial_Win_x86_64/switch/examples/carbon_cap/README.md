This example adds a carbon cap to the 3zone toy problem. The minimum build 
restriction on Nuclear was relaxed to remove associated discrete variables
which enables the export of meaningful dual values from the carbon cost 
constraint.
