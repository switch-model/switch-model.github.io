SYNOPSIS
	switch solve --verbose --log-run

This example illustrates the use of Switch to construct and run a very
simple production-cost model with a single load zone, one investment
period, and four timepoints. Includes variable generation.
