SYNOPSIS
	switch solve --verbose --log-run

This example extends unit_commit by adding spinning reserve requirements.
