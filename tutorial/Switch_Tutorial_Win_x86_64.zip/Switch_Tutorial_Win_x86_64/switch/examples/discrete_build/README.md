SYNOPSIS
	switch solve --verbose --log-run

This example illustrates the use of Switch to construct and run a very
simple model with a single load zone, one investment period, and two
timepoints. Projects are forced to be built in discrete amounts,
according to the unit size specified for each generator technology.
