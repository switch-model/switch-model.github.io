# Copyright (c) 2015-2022 The Switch Authors. All rights reserved.
# Licensed under the Apache License, Version 2.0, which is in the LICENSE file.
"""
This file should not contain anything that is not part of a minimal python
distribution because it needs to be executed before Switch (and its
dependencies) are installed.
"""
__version__ = "2.0.7"
