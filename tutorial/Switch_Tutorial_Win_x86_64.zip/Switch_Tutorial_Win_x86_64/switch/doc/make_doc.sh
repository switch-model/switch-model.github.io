#!/bin/bash
pydoc -w ../
