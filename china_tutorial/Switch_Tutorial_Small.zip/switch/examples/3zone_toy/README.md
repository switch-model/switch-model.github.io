SYNOPSIS
	switch solve --verbose --log-run

This example illustrates the use of Switch to construct and run a toy
model with three load zones and two investment periods where the first
investment period has more temporal resolution than the second.

Note, the results from this have not been fully evaluated.
