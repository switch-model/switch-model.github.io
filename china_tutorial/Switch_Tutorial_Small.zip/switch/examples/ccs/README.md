SYNOPSIS
	switch solve --verbose --log-run

This example adds carbon capture and sequestration (CCS) to the copperplate0
example.