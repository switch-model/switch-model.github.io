SYNOPSIS
	switch solve --verbose --log-run

This example is the same as "copperplate0" but with no existing builds
-- without proj_existing_builds.tab or proj_build_costs.tab.  This is
a regression test for
https://github.com/switch-model/switch/issues/24.
