SYNOPSIS
	switch solve --verbose --log-run

This model expands the copperplate1 example by allowing demand shifting at no
cost. It also decreases available geothermal capacity, and has a tighter
capacity limit on distributed solar solar projects to push other generators
onto the margin to illustrate interesting dynamics between DR, generation
capacity, and local_td capacity.
